#ifndef __KERNEL_INIT_H
#define __KERNEL_INIT_H

void init_all(void);        //初始化所有模块
#endif