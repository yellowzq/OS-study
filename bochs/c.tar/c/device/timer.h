#ifndef __DEVICE_TIMER_H
#define __DEVICE_TIMER_H

void timer_init(void);  //初始化PIT


#endif